/*
 * Activity 4.9.2
 */
public class Gorilla extends Primate
{
  public Gorilla(){}
  public Gorilla(String food, boolean nocturnal, double aveLifeSpan){
    super(food,nocturnal,aveLifeSpan);
    System.out.println("A Gorilla arives.");
  }
  public void grunt()
  {
    System.out.println("The gorilla grunts.");
  }
  public void speak(){
    grunt();
  }
}