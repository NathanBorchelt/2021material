public class Lion extends Feline{
    public void speak(){
        System.out.println("The lion rawrs");
    }
}
