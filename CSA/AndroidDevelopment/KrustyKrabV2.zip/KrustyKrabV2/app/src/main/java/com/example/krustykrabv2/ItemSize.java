package com.example.krustykrabv2;

public interface ItemSize {
    String size();
    double sizeCost();
}
