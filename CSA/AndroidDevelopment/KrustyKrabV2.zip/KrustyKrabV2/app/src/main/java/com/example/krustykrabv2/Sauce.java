package com.example.krustykrabv2;

public interface Sauce {
    boolean sauce();
}
