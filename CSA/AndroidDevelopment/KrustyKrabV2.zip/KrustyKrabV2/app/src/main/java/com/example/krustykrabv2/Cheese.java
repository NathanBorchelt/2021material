package com.example.krustykrabv2;

public interface Cheese {
    boolean cheese();
}
